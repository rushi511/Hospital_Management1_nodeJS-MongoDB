# 🏥 Hospital Management System (Node.js + MongoDB)

A RESTful API built with **Node.js, Express, and MongoDB** to manage hospital workflows:

- Patient registration
- Doctor management
- Appointments
- Admissions & Surgeries
- Payments
- Complete patient flow (patient → appointment → doctor → admission → surgery → payment → discharge)

---

## 🚀 Features

- CRUD APIs for **Patients, Doctors, Appointments, Admissions, Surgeries, and Payments**
- **Flow API** to fetch a patient's full journey with linked data
- MongoDB with **Mongoose ODM**
- Error handling middleware
- Supports **Postman testing** with `x-www-form-urlencoded`

---

## 📂 Project Structure

HospitalManagement/
│── server.js
│── config/
│ └── db.js
│── controllers/
│ ├── patientController.js
│ ├── doctorController.js
│ ├── appointmentController.js
│ ├── admissionController.js
│ ├── surgeryController.js
│ ├── paymentController.js
│ └── flowController.js
│── models/
│ ├── Patient.js
│ ├── Doctor.js
│ ├── Appointment.js
│ ├── Admission.js
│ ├── Surgery.js
│ └── Payment.js
│── routes/
│ ├── patientRoutes.js
│ ├── doctorRoutes.js
│ ├── appointmentRoutes.js
│ ├── admissionRoutes.js
│ ├── surgeryRoutes.js
│ ├── paymentRoutes.js
│ └── flow.js
│── middleware/
│ └── errorMiddleware.js
│── .env
│── package.json
│── README.md

## connect your MongoDB

Setup environment variables (.env)

Create a .env file in the root:

MONGO_URI=mongodb://127.0.0.1:27017(use your database server instead 127.0.0.1:27017)/hospitalDB
PORT=6000

Server will run on:
👉 http://localhost:6000

API Endpoints
👤 Patients

POST /api/patients
GET /api/patients
GET /api/patients/:id
PATCH /api/patients/:id
DELETE /api/patients/:id

🩺 Doctors

POST /api/doctors
GET /api/doctors
GET /api/doctors/:id
PATCH /api/doctors/:id
DELETE /api/doctors/:id

📅 Appointments

POST /api/appointments
GET /api/appointments
GET /api/appointments/:id
PATCH /api/appointments/:id
DELETE /api/appointments/:id

🛏 Admissions

POST /api/admissions
GET /api/admissions
GET /api/admissions/:id
PATCH /api/admissions/:id
DELETE /api/admissions/:id

🏥 Surgeries

POST /api/surgeries
GET /api/surgeries
GET /api/surgeries/:id
PATCH /api/surgeries/:id
DELETE /api/surgeries/:id

💳 Payments

POST /api/payments
GET /api/payments
GET /api/payments/:id
PATCH /api/payments/:id
DELETE /api/payments/:id

🔗 Flow (Full Journey)

GET /api/flow/:id → Get all connected details of a patient (appointments, doctors, admissions, surgeries, payments)
