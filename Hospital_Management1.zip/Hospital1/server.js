const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");

// route files (match your /routes filenames)
const patientRoutes = require("./routes/patientRoutes");
const doctorRoutes = require("./routes/doctorRoutes");
const appointmentRoutes = require("./routes/appointmentRoutes");
const admissionRoutes = require("./routes/admissionRoutes");
const surgeryRoutes = require("./routes/surgeryRoutes");
const paymentRoutes = require("./routes/paymentRoutes");
const flowRoutes = require("./routes/flow");

const { notFound, errorHandler } = require("./middleware/errorMiddleware");

dotenv.config();
connectDB();

const app = express();

// parse JSON and x-www-form-urlencoded (Postman form)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use("/api/patients", patientRoutes);
app.use("/api/doctors", doctorRoutes);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/admissions", admissionRoutes);
app.use("/api/surgeries", surgeryRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/flow", flowRoutes);

// Error middleware
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 6000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
