const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/paymentController");

// Create payment
router.post("/", paymentController.createPayment);

// Get all payments
router.get("/", paymentController.getPayments);

// Get payment by ID
router.get("/:id", paymentController.getPaymentById);

// Update payment
router.patch("/:id", paymentController.updatePayment);

// Delete payment
router.delete("/:id", paymentController.deletePayment);

module.exports = router;
