const express = require("express");
const {
  createSurgery,
  getSurgeries,
  getSurgeryById,
  updateSurgery,
  deleteSurgery,
} = require("../controllers/surgeryController");

const router = express.Router();

router.post("/", createSurgery);
router.get("/", getSurgeries);
router.get("/:id", getSurgeryById);
router.patch("/:id", updateSurgery);
router.delete("/:id", deleteSurgery);

module.exports = router;
