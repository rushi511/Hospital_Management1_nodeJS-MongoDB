const express = require("express");
const {
  createAdmission,
  getAdmissions,
  getAdmissionById,
  updateAdmission,
  deleteAdmission,
} = require("../controllers/admissionController");

const router = express.Router();

router.post("/", createAdmission);
router.get("/", getAdmissions);
router.get("/:id", getAdmissionById);
router.patch("/:id", updateAdmission);
router.delete("/:id", deleteAdmission);

module.exports = router;
