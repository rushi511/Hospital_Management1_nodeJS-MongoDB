const express = require("express");
const router = express.Router();
const { getFullFlow } = require("../controllers/flowController");

router.get("/:id", getFullFlow);

module.exports = router;
