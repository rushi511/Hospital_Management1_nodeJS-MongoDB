const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    // 👇 Keep it as ObjectId if you want relation with Patient
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patient",
      required: true,
    },
    amount: { type: Number, required: true },
    type: {
      type: String,
      enum: ["caseFee", "admission", "surgery", "appointment", "other"],
      default: "other",
    },
    method: {
      type: String,
      enum: ["cash", "card", "insurance", "online", "other"],
      default: "cash",
    },
    paidAt: { type: Date, default: Date.now },
    reference: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Payment", paymentSchema);
