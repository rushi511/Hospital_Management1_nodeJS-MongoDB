const mongoose = require("mongoose");

const surgerySchema = mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: "Doctor", required: true },
    type: { type: String, required: true },
    date: { type: Date, required: true },
    status: { type: String, enum: ["Scheduled", "Completed"], default: "Scheduled" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Surgery", surgerySchema);
