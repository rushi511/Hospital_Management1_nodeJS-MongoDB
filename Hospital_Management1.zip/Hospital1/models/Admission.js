const mongoose = require("mongoose");

const admissionSchema = mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: "Doctor", required: true },
    room: { type: String, required: true },
    status: { type: String, enum: ["Admitted", "Recovered", "Discharged"], default: "Admitted" },
    dischargedAt: { type: Date },
    dischargeNotes: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Admission", admissionSchema);
