const mongoose = require("mongoose");

const doctorSchema = mongoose.Schema(
  {
    firstName: { type: String, required: true },
    lastName: { type: String },
    department: { type: String, required: true },
    specialization: { type: String },
    contactNumber: { type: String },
    email: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Doctor", doctorSchema);
