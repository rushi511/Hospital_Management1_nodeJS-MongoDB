const Admission = require("../models/Admission");

// Create
exports.createAdmission = async (req, res) => {
  try {
    const admission = await Admission.create(req.body);
    res.status(201).json(admission);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Get all
exports.getAdmissions = async (req, res) => {
  const admissions = await Admission.find().populate("patient doctor");
  res.json(admissions);
};

// Get by ID
exports.getAdmissionById = async (req, res) => {
  const admission = await Admission.findById(req.params.id).populate("patient doctor");
  if (!admission) return res.status(404).json({ message: "Admission not found" });
  res.json(admission);
};

// Update
exports.updateAdmission = async (req, res) => {
  const admission = await Admission.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!admission) return res.status(404).json({ message: "Admission not found" });
  res.json(admission);
};

// Delete
exports.deleteAdmission = async (req, res) => {
  const admission = await Admission.findByIdAndDelete(req.params.id);
  if (!admission) return res.status(404).json({ message: "Admission not found" });
  res.json({ message: "Admission deleted successfully" });
};
