const Patient = require("../models/Patient");
const Appointment = require("../models/Appointment");
const Doctor = require("../models/Doctor");
const Surgery = require("../models/Surgery");
const Admission = require("../models/Admission");
const Payment = require("../models/Payment");

exports.getFullFlow = async (req, res) => {
  try {
    const patientId = req.params.id;

    // Fetch patient info
    const patient = await Patient.findById(patientId);
    if (!patient) return res.status(404).json({ message: "Patient not found" });

    // Fetch all related data
    const appointments = await Appointment.find({ patient: patientId }).populate("doctor");
    const admissions = await Admission.find({ patient: patientId });
    const surgeries = await Surgery.find({ patient: patientId });
    const payments = await Payment.find({ patient: patientId });

    res.json({
      patient,
      appointments,
      admissions,
      surgeries,
      payments
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
