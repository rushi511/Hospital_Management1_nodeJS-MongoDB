const Appointment = require("../models/Appointment");

// Create
exports.createAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.create(req.body);
    res.status(201).json(appointment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Get all
exports.getAppointments = async (req, res) => {
  const appointments = await Appointment.find().populate("patient doctor");
  res.json(appointments);
};

// Get by ID
exports.getAppointmentById = async (req, res) => {
  const appointment = await Appointment.findById(req.params.id).populate("patient doctor");
  if (!appointment) return res.status(404).json({ message: "Appointment not found" });
  res.json(appointment);
};

// Update
exports.updateAppointment = async (req, res) => {
  const appointment = await Appointment.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!appointment) return res.status(404).json({ message: "Appointment not found" });
  res.json(appointment);
};

// Delete
exports.deleteAppointment = async (req, res) => {
  const appointment = await Appointment.findByIdAndDelete(req.params.id);
  if (!appointment) return res.status(404).json({ message: "Appointment not found" });
  res.json({ message: "Appointment deleted successfully" });
};
