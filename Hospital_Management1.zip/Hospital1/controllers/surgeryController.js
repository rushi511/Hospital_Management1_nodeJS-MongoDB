const Surgery = require("../models/Surgery");

// Create
exports.createSurgery = async (req, res) => {
  try {
    const surgery = await Surgery.create(req.body);
    res.status(201).json(surgery);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Get all
exports.getSurgeries = async (req, res) => {
  const surgeries = await Surgery.find().populate("patient doctor");
  res.json(surgeries);
};

// Get by ID
exports.getSurgeryById = async (req, res) => {
  const surgery = await Surgery.findById(req.params.id).populate("patient doctor");
  if (!surgery) return res.status(404).json({ message: "Surgery not found" });
  res.json(surgery);
};

// Update
exports.updateSurgery = async (req, res) => {
  const surgery = await Surgery.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!surgery) return res.status(404).json({ message: "Surgery not found" });
  res.json(surgery);
};

// Delete
exports.deleteSurgery = async (req, res) => {
  const surgery = await Surgery.findByIdAndDelete(req.params.id);
  if (!surgery) return res.status(404).json({ message: "Surgery not found" });
  res.json({ message: "Surgery deleted successfully" });
};
