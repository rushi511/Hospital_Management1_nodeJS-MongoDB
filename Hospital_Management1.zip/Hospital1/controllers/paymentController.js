const Payment = require("../models/Payment");

// ✅ Create payment
exports.createPayment = async (req, res) => {
  try {
    console.log("Incoming body:", req.body);

    const patient = req.body.patient || req.body.patientId;
    const { amount, type, method, paidAt, reference } = req.body;

    if (!patient || !amount) {
      return res
        .status(400)
        .json({ message: "patient and amount are required" });
    }

    const payment = await Payment.create({
      patient,
      amount,
      type,
      method,
      paidAt,
      reference,
    });

    console.log("Saved Payment:", payment);
    res.status(201).json(payment);
  } catch (error) {
    console.error("Error saving payment:", error);
    res.status(400).json({ message: error.message });
  }
};

// ✅ Get all payments
exports.getPayments = async (req, res) => {
  try {
    const payments = await Payment.find().populate("patient");
    res.json(payments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Get payment by ID
exports.getPaymentById = async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.id).populate("patient");
    if (!payment) {
      return res.status(404).json({ message: "Payment not found" });
    }
    res.json(payment);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Update payment
exports.updatePayment = async (req, res) => {
  try {
    const payment = await Payment.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!payment) {
      return res.status(404).json({ message: "Payment not found" });
    }
    res.json(payment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// ✅ Delete payment
exports.deletePayment = async (req, res) => {
  try {
    const payment = await Payment.findByIdAndDelete(req.params.id);
    if (!payment) {
      return res.status(404).json({ message: "Payment not found" });
    }
    res.json({ message: "Payment deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
